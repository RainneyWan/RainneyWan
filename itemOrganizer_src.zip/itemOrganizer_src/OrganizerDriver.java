package itemOrganizer;

import itemOrganizer.OrganizerCLI;

public class OrganizerDriver {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        OrganizerCLI cli = new OrganizerCLI();
        cli.run();
    }

}
